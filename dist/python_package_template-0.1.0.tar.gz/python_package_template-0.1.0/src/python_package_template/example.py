from python_package_template.utils import logger


def hello():
    logger.info("Hello world")
